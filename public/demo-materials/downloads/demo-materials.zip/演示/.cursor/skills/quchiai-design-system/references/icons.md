# 曲尺AI 功能图标（业务向内联 SVG）

功能图标**必须**使用本文件中的内联 SVG 或等效自绘路径，**禁止** Lucide / Heroicons / Font Awesome 等通用图标库（易呈现「AI 模板感」）。

品牌 Logo 仍仅用 `../assets/quchi.svg`，见 SKILL.md §11.1。

---

## 使用方式

### 方式 A：页面内 SVG Sprite（推荐，单页 HTML）

在 `<body>` 开头放入 `<svg style="display:none">` 定义区，组件内引用：

```html
<svg class="biz-icon biz-icon--sm" aria-hidden="true"><use href="#qc-check"/></svg>
```

### 方式 B：直接内联（Vue / React 组件）

复制对应 `<symbol>` 内部 path，保留 `viewBox`，去掉 `id`。

### 样式基类

```css
.biz-icon {
  width: 20px;
  height: 20px;
  flex-shrink: 0;
  display: block;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.75;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.biz-icon--sm { width: 16px; height: 16px; }
.biz-icon--on-primary { color: #FFFFFF; }
.biz-icon--accent { color: #22C55E; }
.biz-icon--muted { color: #475569; }
```

---

## Sprite 定义（复制到页面）

```html
<svg xmlns="http://www.w3.org/2000/svg" style="display:none" aria-hidden="true">
  <!-- 特性勾选：圆角方框 + 对勾 -->
  <symbol id="qc-check" viewBox="0 0 16 16">
    <rect x="1.5" y="1.5" width="13" height="13" rx="3" stroke="currentColor" fill="none"/>
    <path d="M4.5 8.2 7 10.7 11.5 5.3" stroke="currentColor" fill="none"/>
  </symbol>
  <!-- 右箭头（按钮 / 卡片） -->
  <symbol id="qc-arrow-right" viewBox="0 0 16 16">
    <path d="M3 8h9M9 4.5 12.5 8 9 11.5" stroke="currentColor" fill="none"/>
  </symbol>
  <!-- 上箭头（回到顶部） -->
  <symbol id="qc-arrow-up" viewBox="0 0 16 16">
    <path d="M8 12V4M4.5 7.5 8 4 11.5 7.5" stroke="currentColor" fill="none"/>
  </symbol>
  <!-- 汉堡菜单 -->
  <symbol id="qc-menu" viewBox="0 0 16 16">
    <path d="M2.5 4.5h11M2.5 8h11M2.5 11.5h11" stroke="currentColor" fill="none"/>
  </symbol>
  <!-- 用户注册 -->
  <symbol id="qc-user" viewBox="0 0 16 16">
    <circle cx="8" cy="5" r="2.5" stroke="currentColor" fill="none"/>
    <path d="M3.5 13c0-2.5 2-4 4.5-4s4.5 1.5 4.5 4" stroke="currentColor" fill="none"/>
  </symbol>
  <!-- API 密钥 -->
  <symbol id="qc-key" viewBox="0 0 16 16">
    <circle cx="5.5" cy="8" r="3" stroke="currentColor" fill="none"/>
    <path d="M8 8h5.5M12 6v4" stroke="currentColor" fill="none"/>
  </symbol>
  <!-- 接口 / 链路 -->
  <symbol id="qc-api" viewBox="0 0 16 16">
    <rect x="2" y="4" width="5" height="8" rx="1.5" stroke="currentColor" fill="none"/>
    <rect x="9" y="4" width="5" height="8" rx="1.5" stroke="currentColor" fill="none"/>
    <path d="M7 8h2" stroke="currentColor" fill="none"/>
  </symbol>
  <!-- 运营 / 监控 -->
  <symbol id="qc-chart" viewBox="0 0 16 16">
    <path d="M2.5 12.5V6M6.5 12.5V3.5M10.5 12.5V8M14 12.5v-5" stroke="currentColor" fill="none"/>
  </symbol>
  <!-- 安全盾牌 -->
  <symbol id="qc-shield" viewBox="0 0 16 16">
    <path d="M8 2 12 4v4c0 2.5-1.8 4.5-4 5.5C5.8 12.5 4 10.5 4 8V4l4-2z" stroke="currentColor" fill="none"/>
  </symbol>
  <!-- 性能闪电 -->
  <symbol id="qc-bolt" viewBox="0 0 16 16">
    <path d="M9 2 5 9h3.5L7 14l5-7H8.5L9 2z" stroke="currentColor" fill="none" stroke-linejoin="miter"/>
  </symbol>
  <!-- 多模型 / 层叠 -->
  <symbol id="qc-layers" viewBox="0 0 16 16">
    <path d="M8 2 13 5 8 8 3 5 8 2zM3 8l5 3 5-3M3 11l5 3 5-3" stroke="currentColor" fill="none"/>
  </symbol>
  <!-- 镜像 / 容器 -->
  <symbol id="qc-box" viewBox="0 0 16 16">
    <path d="M2.5 5 8 2.5 13.5 5V11L8 13.5 2.5 11V5z" stroke="currentColor" fill="none"/>
    <path d="M8 8 13.5 5M8 8v5.5M8 8 2.5 5" stroke="currentColor" fill="none"/>
  </symbol>
  <!-- 微调 / 滑杆 -->
  <symbol id="qc-sliders" viewBox="0 0 16 16">
    <path d="M2 4h12M2 8h12M2 12h12" stroke="currentColor" fill="none"/>
    <circle cx="5" cy="4" r="1.25" fill="currentColor"/>
    <circle cx="10" cy="8" r="1.25" fill="currentColor"/>
    <circle cx="7" cy="12" r="1.25" fill="currentColor"/>
  </symbol>
  <!-- 训练 / 芯片 -->
  <symbol id="qc-chip" viewBox="0 0 16 16">
    <rect x="4" y="4" width="8" height="8" rx="1.5" stroke="currentColor" fill="none"/>
    <path d="M6 2v2M8 2v2M10 2v2M6 12v2M8 12v2M10 12v2M2 6h2M2 8h2M2 10h2M12 6h2M12 8h2M12 10h2" stroke="currentColor" fill="none"/>
  </symbol>
</svg>
```

---

## 场景对照表

| 业务场景 | symbol id | 颜色建议 |
|----------|-----------|----------|
| 特性列表勾选 | `qc-check` | `#22C55E` |
| 主/次按钮箭头 | `qc-arrow-right` | 继承按钮文字色 |
| 小卡片标题旁 | `qc-arrow-right` | `#94A3B8`，hover `#2563EB` |
| 移动菜单 | `qc-menu` | `#475569` |
| 回到顶部 | `qc-arrow-up` | `#475569` |
| 步骤：注册 | `qc-user` | 白（渐变圆底内） |
| 步骤：密钥 | `qc-key` | 白 |
| 步骤：调用 | `qc-api` | 白 |
| 步骤：运营 | `qc-chart` | 白 |
| 特性：安全 | `qc-shield` | `#22C55E` |
| 特性：性能 | `qc-bolt` | `#22C55E` |
| 特性：多模型 | `qc-layers` | `#22C55E` |
| 产品：镜像广场 | `qc-box` | 卡片标题区可选 |
| 产品：微调 | `qc-sliders` | 同上 |
| 产品：训练 | `qc-chip` | 同上 |

---

## 禁止示例

```html
<!-- ❌ Lucide / 图标库 -->
<script src="https://unpkg.com/lucide@latest"></script>

<!-- ❌ 用品牌 quchi 当勾选 -->
<img src="quchi.svg" class="feature-check" />

<!-- ❌ emoji -->
<div class="step-icon">🤖</div>
```
