# 曲尺AI 组件代码参考

本文件包含可直接复用的 HTML/CSS 组件片段，严格遵循曲尺AI设计规范。

**图标分工**（见 SKILL.md §十一）：
- **品牌**：`../assets/quchi.svg` — 仅 Logo、Favicon、品牌水印
- **功能**：`icons.md` 中 `qc-*` 业务 SVG — 勾选、步骤、导航工具等

交付前完成 SKILL.md §十二 QA 自检。

---

## 0. 图标引用

### 0.1 品牌图标（quchi.svg）

将 `../assets/quchi.svg` 复制到项目的 `public/` 或 `src/assets/` 后，**仅**用于品牌场景：

```html
<!-- 导航 Logo -->
<img class="quchi-icon quchi-icon--lg" src="/quchi.svg" alt="曲尺AI" />

<!-- 卡片品牌水印（装饰） -->
<img class="quchi-icon quchi-icon--watermark" src="/quchi.svg" alt="" aria-hidden="true" />
```

```css
.quchi-icon { display: block; width: auto; height: 28px; flex-shrink: 0; }
.quchi-icon--lg { height: 32px; }
.quchi-icon--watermark { height: 56px; opacity: 0.12; pointer-events: none; }
```

### 0.2 功能图标（Lucide 等）

```html
<!-- 特性列表勾选 -->
<svg class="ui-icon ui-icon--sm" aria-hidden="true"><!-- lucide:check，color #22C55E --></svg>

<!-- 步骤流（置于 .step-icon 渐变圆内，白色 stroke） -->
<svg class="ui-icon" aria-hidden="true"><!-- lucide:bot / zap / user 等 --></svg>

<!-- 导航工具按钮 -->
<button class="btn-icon" aria-label="切换语言">
  <svg class="ui-icon" aria-hidden="true"><!-- lucide:globe --></svg>
</button>
```

```css
.ui-icon { width: 20px; height: 20px; flex-shrink: 0; stroke: currentColor; }
.ui-icon--sm { width: 16px; height: 16px; }
```

---

## 1. CSS 变量基础（Design Tokens）

**单一来源**：`../assets/quchi-tokens.css`（与 SKILL.md §二 一致；**勿**在本文件或页面内再写一份 `:root`）。

引入方式：

```html
<link rel="stylesheet" href="../assets/quchi-tokens.css" />
```

```css
@import "../assets/quchi-tokens.css";
```

集成到项目时，将 `quchi-tokens.css` 与 `quchi.svg` 一并复制到 `public/` 或 `src/styles/`，组件样式统一使用 `var(--primary)` 等变量。

---

## 2. 主按钮

```html
<button class="btn-primary">免费生成项目原型 →</button>
<button class="btn-outline">立即联系 →</button>
<button class="btn-dark">模型广场 →</button>
```

```css
.btn-primary {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  background: var(--primary);
  color: var(--text-white);
  padding: 12px 28px;
  border-radius: var(--radius-sm);
  font-family: var(--font);
  font-size: 15px;
  font-weight: 600;
  border: none;
  cursor: pointer;
  transition: all 0.2s ease;
}
.btn-primary:hover {
  background: var(--primary-dark);
  transform: translateY(-1px);
  box-shadow: 0 4px 16px rgba(37, 99, 235, 0.3);
}

.btn-outline {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  background: transparent;
  color: var(--primary);
  padding: 11px 27px;
  border-radius: var(--radius-sm);
  font-family: var(--font);
  font-size: 15px;
  font-weight: 600;
  border: 1.5px solid var(--primary);
  cursor: pointer;
  transition: all 0.2s ease;
}
.btn-outline:hover {
  background: rgba(37, 99, 235, 0.04);
  transform: translateY(-1px);
}

.btn-dark {
  background: var(--primary-deep);
  color: var(--text-white);
  /* 其余同 btn-primary */
}
```

---

## 3. 标准内容卡片

```html
<div class="card">
  <div class="card-badge">海量模型</div>
  <h3 class="card-title">大模型API服务</h3>
  <p class="card-desc">按需调用全球领先的预训练大模型；自有算力直供，成本更低，响应更快。</p>
  <ul class="feature-list">
    <li>
      <svg class="ui-icon ui-icon--sm feature-check" aria-hidden="true"><!-- lucide:check --></svg>
      <div><strong>按量付费</strong><p>极致性价比，仅为您的有效调用付费</p></div>
    </li>
    <li>
      <svg class="ui-icon ui-icon--sm feature-check" aria-hidden="true"><!-- lucide:check --></svg>
      <div><strong>企业级安全</strong><p>数据链路全程加密，符合国家安全标准</p></div>
    </li>
    <li>
      <svg class="ui-icon ui-icon--sm feature-check" aria-hidden="true"><!-- lucide:check --></svg>
      <div><strong>毫秒级响应</strong><p>自有算力，响应快、不排队</p></div>
    </li>
  </ul>
  <button class="btn-dark">模型广场 →</button>
  <!-- 可选：右下角品牌水印 -->
  <img class="quchi-icon quchi-icon--watermark card-watermark" src="/quchi.svg" alt="" aria-hidden="true" />
</div>
```

```css
.card {
  background: var(--bg-white);
  border-radius: var(--radius-lg);
  padding: 40px;
  box-shadow: var(--shadow-card);
  position: relative;
  transition: box-shadow 0.25s ease, transform 0.25s ease;
}
.card:hover {
  box-shadow: var(--shadow-hover);
  transform: translateY(-4px);
}

.card-watermark {
  position: absolute;
  right: 24px;
  bottom: 24px;
}

.card-badge {
  display: inline-block;
  background: var(--grad-badge);
  color: var(--text-white);
  padding: 3px 12px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 600;
  margin-bottom: 16px;
}

.card-title {
  font-size: 22px;
  font-weight: 700;
  color: var(--text-primary);
  margin: 0 0 12px;
}

.card-desc {
  font-size: 14px;
  color: var(--text-body);
  line-height: 1.75;
  margin: 0 0 24px;
}

.feature-list {
  list-style: none;
  padding: 0;
  margin: 0 0 32px;
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
}
.feature-list li {
  display: flex;
  align-items: flex-start;
  gap: 8px;
}
.feature-check {
  margin-top: 2px;
  color: #22C55E;
}
.feature-list strong {
  display: block;
  font-size: 14px;
  font-weight: 600;
  color: var(--text-primary);
  margin-bottom: 2px;
}
.feature-list p {
  font-size: 12px;
  color: var(--text-muted);
  margin: 0;
  line-height: 1.5;
}
```

---

## 4. 小功能卡片（镜像广场 / 微调 / 训练）

```html
<div class="mini-card">
  <div class="mini-card-header">
    <h4>镜像广场</h4>
    <span class="arrow-link">→</span>
  </div>
  <p>无需从零开发，选择我们为您预置的智能体(Agent)和应用镜像，即刻拥有强大AI能力。</p>
</div>
```

```css
.mini-card {
  background: var(--bg-white);
  border-radius: var(--radius-md);
  padding: 28px 32px;
  box-shadow: var(--shadow-card);
  transition: all 0.25s ease;
  cursor: pointer;
}
.mini-card:hover {
  box-shadow: var(--shadow-hover);
  transform: translateY(-4px);
}
.mini-card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}
.mini-card h4 {
  font-size: 18px;
  font-weight: 700;
  color: var(--text-primary);
  margin: 0;
}
.arrow-link {
  font-size: 18px;
  color: var(--text-muted);
  transition: color 0.2s, transform 0.2s;
}
.mini-card:hover .arrow-link {
  color: var(--primary);
  transform: translateX(4px);
}
.mini-card p {
  font-size: 14px;
  color: var(--text-body);
  line-height: 1.75;
  margin: 0;
}
```

---

## 5. 导航栏

```html
<nav class="navbar">
  <div class="navbar-inner">
    <div class="logo">
      <img class="quchi-icon quchi-icon--lg" src="/quchi.svg" alt="曲尺AI" />
    </div>
    <ul class="nav-links">
      <li class="active"><a href="#">首页</a></li>
      <li><a href="#">软件定制</a></li>
      <li><a href="#">模型广场</a></li>
      <li><a href="#">智能体中心</a></li>
      <li><a href="#">镜像广场</a></li>
      <li><a href="#">体验中心</a></li>
      <li><a href="#">价格</a></li>
      <li><a href="#">文档</a></li>
    </ul>
    <div class="nav-actions">
      <button class="btn-icon" aria-label="切换语言">
        <svg class="ui-icon" aria-hidden="true"><!-- lucide:globe --></svg>
      </button>
      <a href="#">工作台</a>
      <a href="#">API Key</a>
      <button class="btn-primary" style="padding: 8px 20px; font-size: 14px;">登录/注册</button>
    </div>
  </div>
</nav>
```

```css
.navbar {
  position: fixed;
  top: 0; left: 0; right: 0;
  height: 64px;
  background: var(--bg-white);
  border-bottom: 1px solid var(--border);
  z-index: 100;
}
.navbar-inner {
  max-width: 1280px;
  margin: 0 auto;
  padding: 0 40px;
  height: 100%;
  display: flex;
  align-items: center;
  gap: 40px;
}
.nav-links {
  display: flex;
  list-style: none;
  margin: 0;
  padding: 0;
  gap: 28px;
  flex: 1;
}
.nav-links a {
  font-size: 14px;
  font-weight: 500;
  color: var(--text-body);
  text-decoration: none;
  transition: color 0.2s;
}
.nav-links li.active a,
.nav-links a:hover {
  color: var(--primary);
}
.nav-actions {
  display: flex;
  align-items: center;
  gap: 16px;
}
.nav-actions a {
  font-size: 14px;
  color: var(--text-body);
  text-decoration: none;
}
.btn-icon {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 6px;
  border: none;
  background: transparent;
  color: var(--text-body);
  cursor: pointer;
  border-radius: var(--radius-sm);
  transition: color 0.2s, background 0.2s;
}
.btn-icon:hover {
  color: var(--primary);
  background: rgba(37, 99, 235, 0.06);
}
```

---

## 6. Hero Section

```html
<section class="hero">
  <div class="hero-inner">
    <div class="hero-content">
      <h1>找软件定开，上曲尺AI</h1>
      <p>用自然语言描述你的业务需求，曲尺AI 快速生成项目原型、功能方案与交付路径，后续由专业团队完成定制开发与运维。</p>
      <button class="btn-primary" style="font-size: 16px; padding: 14px 32px;">
        免费生成项目原型 →
      </button>
    </div>
    <div class="hero-visual">
      <!-- 3D 插图区域；可选品牌徽章：quchi.svg -->
    </div>
  </div>
  <!-- 页面导航条 -->
  <div class="hero-nav-bar">
    <a href="#">免费试用 →<span>零门槛试用智能体，亲测AI无限可能</span></a>
    <a href="#">接入模型 →<span>按需调用主流模型，快速集成AI功能</span></a>
    <a href="#">获取镜像 →<span>体验优质镜像服务，助力团队高效开发</span></a>
    <a href="#">了解价格 →<span>释放技术红利，追求极致性价比</span></a>
  </div>
</section>
```

```css
.hero {
  background: linear-gradient(160deg, #EEF2F9 0%, #DBEAFE 60%, #EEF2F9 100%);
  padding-top: 64px; /* 导航栏高度 */
  min-height: 560px;
}
.hero-inner {
  max-width: 1280px;
  margin: 0 auto;
  padding: 80px 40px 60px;
  display: grid;
  grid-template-columns: 1fr 1fr;
  align-items: center;
  gap: 60px;
}
.hero-content h1 {
  font-size: 56px;
  font-weight: 900;
  color: var(--text-primary);
  line-height: 1.2;
  margin: 0 0 20px;
}
.hero-content p {
  font-size: 16px;
  color: var(--text-body);
  line-height: 1.75;
  margin: 0 0 36px;
  max-width: 480px;
}

/* 底部快捷导航 */
.hero-nav-bar {
  border-top: 1px solid rgba(37, 99, 235, 0.1);
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  max-width: 1280px;
  margin: 0 auto;
}
.hero-nav-bar a {
  padding: 24px 40px;
  border-right: 1px solid var(--border);
  text-decoration: none;
  font-size: 15px;
  font-weight: 600;
  color: var(--text-primary);
  display: flex;
  flex-direction: column;
  gap: 6px;
  transition: background 0.2s;
  background: var(--bg-white);
}
.hero-nav-bar a:hover { background: rgba(37, 99, 235, 0.03); }
.hero-nav-bar a span {
  font-size: 13px;
  font-weight: 400;
  color: var(--text-muted);
}
```

---

## 7. 全宽 CTA Banner

```html
<section class="cta-banner">
  <h2>立即体验，创造未来</h2>
  <a href="#" class="cta-btn">立即试用 →</a>
</section>
```

```css
.cta-banner {
  background: var(--grad-primary);
  text-align: center;
  padding: 80px 40px;
}
.cta-banner h2 {
  font-size: 44px;
  font-weight: 800;
  color: var(--text-white);
  margin: 0 0 40px;
}
.cta-btn {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background: rgba(255,255,255,0.15);
  border: 1.5px solid rgba(255,255,255,0.5);
  color: var(--text-white);
  padding: 16px 48px;
  border-radius: var(--radius-md);
  font-size: 16px;
  font-weight: 600;
  text-decoration: none;
  min-width: 320px;
  justify-content: space-between;
  backdrop-filter: blur(4px);
  transition: background 0.2s;
}
.cta-btn:hover {
  background: rgba(255,255,255,0.25);
}
```

---

## 8. 横向步骤流

```html
<div class="step-flow">
  <div class="step">
    <div class="step-icon">
      <svg class="ui-icon" aria-hidden="true"><!-- lucide:bot，白色 --></svg>
    </div>
    <h4>AI 需求分析</h4>
    <p>AI引导式对话，帮你完善需求</p>
  </div>
  <div class="step-arrow">
    <svg class="ui-icon" aria-hidden="true"><!-- lucide:chevron-right，#93C5FD --></svg>
  </div>
  <div class="step">
    <div class="step-icon">
      <svg class="ui-icon" aria-hidden="true"><!-- lucide:zap --></svg>
    </div>
    <h4>分钟级出原型</h4>
    <p>分钟级输出高保真原型，快！</p>
  </div>
  <!-- 更多步骤：user / code / shield / headphones -->
</div>
```

```css
.step-flow {
  display: flex;
  align-items: flex-start;
  gap: 0;
  padding: 40px;
  background: var(--bg-white);
  border-radius: var(--radius-lg);
}
.step {
  flex: 1;
  text-align: center;
  padding: 0 16px;
}
.step-icon {
  width: 48px;
  height: 48px;
  background: var(--grad-primary);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 16px;
  color: var(--text-white);
}
.step h4 {
  font-size: 15px;
  font-weight: 700;
  color: var(--text-primary);
  margin: 0 0 6px;
}
.step p {
  font-size: 13px;
  color: var(--text-muted);
  margin: 0;
  line-height: 1.5;
}
.step-arrow {
  color: #93C5FD;
  margin-top: 14px;
  flex-shrink: 0;
  display: flex;
  align-items: center;
}
```
