# 曲尺AI 页面交付检查（编码 · 布局 · 图标）

生成或修改任何 HTML / Vue / React 页面前**必须先读本文**，与 `SKILL.md` §十二 QA 一并执行。

---

## 一、中文与文件编码（强制）

### 必须做

1. 源文件保存为 **UTF-8（无 BOM）**。
2. `<head>` 内第一行元信息之后立即写：`<meta charset="UTF-8" />`。
3. 静态 HTML 在 `<html>` 上写 `lang="zh-CN"`。
4. 所有中文文案在编辑器中**肉眼核对**，禁止出现 ``、`?` 替代汉字、或未闭合标签（如 `</p>` 被吃掉）。
5. 输出/写入文件后，用只读方式打开文件抽查标题、首屏 H1、按钮文案是否正常显示中文。

### 禁止做

- ❌ 依赖终端默认编码（如 GBK）保存含中文的 HTML。
- ❌ 在可能被错误转码的环境用裸写 `→`、`·` 等符号；优先用 **内联 SVG 箭头** 或 HTML 实体 `&rarr;`。
- ❌ 复制粘贴后未检查即交付（常见：`台?`、`全链?` 等截断乱码）。

### 乱码自检关键词

若页面出现下列模式，**整文件按 UTF-8 重写**，不要局部替换：

- `` 或连续 `?` 出现在中文中间
- `</strong>` / `</p>` / `</button>` 等标签缺失，导致布局塌陷
- `aria-label` 或 `title` 中文不完整

---

## 二、布局防错（强制）

### 全局

```css
*, *::before, *::after { box-sizing: border-box; }
body { overflow-x: hidden; }
.container {
  max-width: 1280px;
  margin: 0 auto;
  padding: 0 40px;
  width: 100%;
}
```

- 所有栅格列使用 `minmax(0, 1fr)` 或子项 `min-width: 0`，避免 flex/grid 子项撑破容器。
- 固定导航高度 `64px`，主内容区 `padding-top: 64px`（或首屏 Hero 自带 `padding-top`）。

### 导航

- `.navbar-inner` 设 `position: relative`（移动端下拉菜单定位参照）。
- 桌面：`.nav-links { flex: 1; min-width: 0; }`，链接过多时减小 `gap` 或隐藏次要项，**禁止**导航条水平溢出。
- 移动（≤1024px）：汉堡菜单 + 全宽下拉，`.nav-links.open` 绝对定位在导航下方。

### Hero

- 双栏：`grid-template-columns: 1fr 1fr`，≤1024px 改单列。
- 浮动标签：`right` 不得为负百分比；父级 `.hero-visual { overflow: hidden; }`。
- 底部四格快捷栏与主内容同 `max-width: 1280px`，边框对齐。

### 卡片与步骤

- 双栏大卡、三栏小卡：`gap: 24px`，≤1024px 单列。
- 特性列表 2 列，≤1024px 改 1 列。
- 步骤条 ≤1024px 允许换行；虚线连接线在窄屏 `display: none`。

### 响应式断点（统一）

| 断点 | 用途 |
|------|------|
| 1280px | 内容最大宽度 |
| 1024px | 导航折叠、Hero/栅格单列 |
| 640px | 容器左右 padding 20px、快捷栏单列 |

交付前在 **1280 / 1024 / 375** 三档目视检查：无横向滚动条、无重叠、无文字挤出卡片。

---

## 三、图标分工（与 SKILL.md §十一一致）

| 类型 | 来源 | 场景 |
|------|------|------|
| 品牌 | `assets/quchi.svg` | Logo、Favicon、品牌水印、Hero 品牌徽章 |
| 功能 | `references/icons.md` 内联 SVG / sprite | 勾选、步骤、菜单、箭头等 |

**禁止**：Lucide、Heroicons、Font Awesome、Tabler、Material Icons、emoji 充当 UI 图标。

---

## 四、样式令牌

- 颜色 / 圆角 / 阴影以 `assets/quchi-tokens.css` 为唯一 `:root` 来源
- 通过 `<link>` 或 `@import` 引入；勿在 `components.md` 与页面 `<style>` 中重复定义令牌

## 五、示例页

`examples/quchiai-product-homepage.html` 为合规参考实现。
